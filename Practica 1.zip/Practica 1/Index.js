function pulsar() {
alert("A oprimido un boton");
}